"""The Networking page (M21, Phase 3): run and reach PAIOS without ever
opening a terminal.

Shows the live picture — hostname, LAN IP, port, server + API status,
access mode, firewall and Wi-Fi — and gives every control as a button:

    * Start / Stop / Restart the API (a local process controller, since
      a dead server cannot be reached over REST);
    * Local Only  <->  Local Network (the persisted access mode; the
      server rebinds to it on the next start);
    * Copy the address a phone should use, and show it as a QR code;
    * Open the Windows firewall for the port (with a clear message when
      it needs administrator rights).

Facts come from GET /system/network; mutations POST/PUT there. The page
never raises into the poll loop.
"""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from paios_gui.client import ApiResponseError, ApiUnreachable
from paios_gui.server_control import ServerController
from paios_gui.theme import ACCENT, BAD, GOOD, TEXT_DIM, WARN


class NetworkingPage(QWidget):
    title = "Networking"

    #: Facts shown in the status grid: (row label, state-key).
    _FACTS = (
        ("Computer name", "hostname"),
        ("Local IP address", "lan_ip"),
        ("Port", "port"),
        ("Wi-Fi network", "wifi_ssid"),
    )

    def __init__(self, window) -> None:
        super().__init__()
        self._window = window
        self._controller = ServerController(window.client.base_url)
        self._last: dict = {}

        outer = QVBoxLayout(self)
        heading = QLabel("NETWORKING")
        heading.setObjectName("sectionTitle")
        outer.addWidget(heading)

        # --- status chips row --------------------------------------------
        chips = QHBoxLayout()
        self.server_chip = self._chip("Server")
        self.mode_chip = self._chip("Mode")
        self.firewall_chip = self._chip("Firewall")
        for chip in (self.server_chip, self.mode_chip, self.firewall_chip):
            chips.addWidget(chip)
        chips.addStretch(1)
        outer.addLayout(chips)

        # --- facts grid --------------------------------------------------
        facts_frame = QFrame()
        facts_frame.setObjectName("card")
        self._grid = QGridLayout(facts_frame)
        self._value_labels: dict[str, QLabel] = {}
        for row, (label_text, key) in enumerate(self._FACTS):
            name = QLabel(label_text)
            name.setObjectName("subtitle")
            value = QLabel("—")
            self._grid.addWidget(name, row, 0)
            self._grid.addWidget(value, row, 1)
            self._value_labels[key] = value
        outer.addWidget(facts_frame)

        # --- server controls ---------------------------------------------
        outer.addWidget(self._section_label("Server"))
        server_row = QHBoxLayout()
        self.start_button = self._button("Start", self._on_start, server_row)
        self.stop_button = self._button("Stop", self._on_stop, server_row)
        self.restart_button = self._button(
            "Restart", self._on_restart, server_row
        )
        server_row.addStretch(1)
        outer.addLayout(server_row)

        # --- access mode -------------------------------------------------
        outer.addWidget(self._section_label("Access"))
        self.access_hint = QLabel("")
        self.access_hint.setObjectName("subtitle")
        self.access_hint.setWordWrap(True)
        outer.addWidget(self.access_hint)
        access_row = QHBoxLayout()
        self.local_button = self._button(
            "Local Only", lambda: self._on_set_mode("local"), access_row
        )
        self.lan_button = self._button(
            "Local Network", lambda: self._on_set_mode("lan"), access_row
        )
        self.firewall_button = self._button(
            "Open firewall", self._on_open_firewall, access_row
        )
        access_row.addStretch(1)
        outer.addLayout(access_row)

        # --- address + QR ------------------------------------------------
        outer.addWidget(self._section_label("Connect a phone"))
        self.address_label = QLabel("—")
        self.address_label.setObjectName("todayHeader")
        self.address_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        outer.addWidget(self.address_label)
        address_row = QHBoxLayout()
        self.copy_button = self._button(
            "Copy address", self._on_copy_address, address_row
        )
        self.qr_button = self._button(
            "Show QR code", self._on_toggle_qr, address_row
        )
        address_row.addStretch(1)
        outer.addLayout(address_row)
        self.qr_label = QLabel("")
        self.qr_label.hide()
        outer.addWidget(self.qr_label)
        self.status_line = QLabel("")
        self.status_line.setObjectName("subtitle")
        self.status_line.setWordWrap(True)
        outer.addWidget(self.status_line)

        outer.addStretch(1)

    # --- builders --------------------------------------------------------

    def _chip(self, text: str) -> QLabel:
        chip = QLabel(text)
        chip.setObjectName("statusChip")
        chip.setStyleSheet(f"background:{TEXT_DIM}; color:#14161a;")
        return chip

    def _section_label(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setObjectName("cardTitle")
        return label

    def _button(self, text: str, handler, row) -> QPushButton:
        button = QPushButton(text)
        button.clicked.connect(handler)
        row.addWidget(button)
        return button

    def _paint_chip(self, chip: QLabel, color: str, text: str) -> None:
        chip.setText(text)
        chip.setStyleSheet(f"background:{color}; color:#14161a;")

    # --- data ------------------------------------------------------------

    def refresh(self, client) -> None:
        """Read facts + server status; repaint. Never raises."""
        try:
            facts = client.system_network()
        except ApiUnreachable:
            facts = {}
            self._paint_chip(self.server_chip, BAD, "Server: offline")
        except ApiResponseError as error:
            self.status_line.setText(f"Server error: {error}")
            return
        self._last = facts
        self._paint_facts(facts)
        self._paint_server_state()

    def _paint_facts(self, facts: dict) -> None:
        for key, label in self._value_labels.items():
            value = facts.get(key)
            label.setText(str(value) if value not in (None, "") else "—")

        mode = facts.get("mode", "local")
        if mode == "lan":
            self._paint_chip(self.mode_chip, GOOD, "Local Network")
            self.access_hint.setText(
                "Local Network: phones paired with this desktop can reach"
                " PAIOS over the same Wi-Fi. Keep the firewall open for the"
                " port below."
            )
        else:
            self._paint_chip(self.mode_chip, ACCENT, "Local Only")
            self.access_hint.setText(
                "Local Only: PAIOS accepts connections from this computer"
                " alone (the safe default). Switch to Local Network to"
                " connect your phone over Wi-Fi."
            )
        self.local_button.setEnabled(mode != "local")
        self.lan_button.setEnabled(mode != "lan")

        firewall = facts.get("firewall_rule")
        if firewall is True:
            self._paint_chip(self.firewall_chip, GOOD, "Firewall: open")
            self.firewall_button.setEnabled(False)
        elif firewall is False:
            self._paint_chip(self.firewall_chip, WARN, "Firewall: closed")
            self.firewall_button.setEnabled(True)
        else:
            self._paint_chip(self.firewall_chip, TEXT_DIM, "Firewall: n/a")
            self.firewall_button.setEnabled(False)

        address = facts.get("lan_url") if mode == "lan" else facts.get(
            "loopback_url"
        )
        self.address_label.setText(address or "—")
        # Refresh a shown QR to match the current address.
        if not self.qr_label.isHidden() and address:
            self._render_qr(address)

    def _paint_server_state(self) -> None:
        state = self._controller.status()
        if state["reachable"]:
            managed = "" if state["external"] else " (managed here)"
            self._paint_chip(
                self.server_chip, GOOD, f"Server: running{managed}"
            )
            self.start_button.setEnabled(False)
            self.stop_button.setEnabled(not state["external"])
            self.restart_button.setEnabled(True)
        elif state["state"] == "starting":
            self._paint_chip(self.server_chip, WARN, "Server: starting…")
            self.start_button.setEnabled(False)
            self.stop_button.setEnabled(True)
            self.restart_button.setEnabled(False)
        else:
            self._paint_chip(self.server_chip, BAD, "Server: stopped")
            self.start_button.setEnabled(True)
            self.stop_button.setEnabled(False)
            self.restart_button.setEnabled(True)

    # --- server actions --------------------------------------------------

    def _on_start(self) -> None:
        self._report(self._controller.start(), "started")

    def _on_stop(self) -> None:
        self._report(self._controller.stop(), "stopped")

    def _on_restart(self) -> None:
        self._report(self._controller.restart(), "started")

    def _report(self, result: dict, ok_key: str) -> None:
        self.status_line.setText(result.get("reason", ""))
        kind = "ok" if result.get(ok_key) else "warn"
        self._window.notify(result.get("reason", ""), kind)
        self._paint_server_state()

    # --- mode + firewall -------------------------------------------------

    def _on_set_mode(self, mode: str) -> None:
        def call():
            result = self._window.client.set_network_mode(mode)
            self.status_line.setText(result.get("note", ""))

        self._window.run_action(
            call,
            "Local Network enabled — restart the server to apply"
            if mode == "lan"
            else "Local Only enabled — restart the server to apply",
        )

    def _on_open_firewall(self) -> None:
        try:
            result = self._window.client.open_firewall()
        except ApiUnreachable as error:
            self.status_line.setText(f"Offline: {error}")
            return
        except ApiResponseError as error:
            self.status_line.setText(f"Server error: {error}")
            return
        self.status_line.setText(result.get("detail", ""))
        self._window.notify(
            result.get("detail", ""),
            "ok" if result.get("ok") else "warn",
        )

    # --- address + QR ----------------------------------------------------

    def _on_copy_address(self) -> None:
        address = self.address_label.text()
        if not address or address == "—":
            return
        QApplication.clipboard().setText(address)
        self._window.notify(f"Copied {address}", "ok")

    def _on_toggle_qr(self) -> None:
        if not self.qr_label.isHidden():
            self.qr_label.hide()
            self.qr_button.setText("Show QR code")
            return
        address = self.address_label.text()
        if not address or address == "—":
            return
        self._render_qr(address)
        self.qr_label.show()
        self.qr_button.setText("Hide QR code")

    def _render_qr(self, address: str) -> None:
        from paios_gui import qr

        self.qr_label.setPixmap(qr.pixmap(address))
